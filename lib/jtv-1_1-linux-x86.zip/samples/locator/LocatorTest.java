/*
 * @(#)LocatorTest.java	1.3 05/11/23
 * 
 * Copyright � 2005 Sun Microsystems, Inc. All rights reserved. 
 * Use is subject to license terms.
 * 
 */

import javax.tv.locator.Locator;
import javax.tv.locator.LocatorFactory;
import javax.tv.locator.MalformedLocatorException;

public class LocatorTest {

    private static void prt(String msg) {
        System.out.println("LocatorTest:"+ msg);
    }

    public static void main(String args[]) {
        boolean passed = true;
        prt("Starting LocatorTest...");

        Locator loc = null;
        Locator locators[] = null;
        LocatorFactory factory = null;

        try {
            factory = LocatorFactory.getInstance();
            if (factory == null) {
                throw new Exception("LocatorFactory.getInstance() == null");
            }

            try {
                loc = factory.createLocator("service:/NBC");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
        
            try {
                locators = factory.transformLocator(loc);
                if (locators == null) {
                    throw new Exception("factory.transformLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }

            if (loc.hasMultipleTransformations() == true) {
                prt("FAILURE: locator.hasMultipleTransforms() == true");
                new Exception().printStackTrace();
            }

            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("component:/NBC-AUDIO");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("component:/NBC-VIDEO");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("event:/Friends");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("event:/Wide World of Sports");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("transport:/transport1");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("network:/network1");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("bouquet:/TCIPremiumPackage");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());

            try {
                loc = factory.createLocator("rtp:/129.127.65.14");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("http:/www.xmedia.com/DebbieDoesDetroit.mpg");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }
        
            prt("FYI: toExternalForm = " + loc.toExternalForm());
        
            try {
                loc = factory.createLocator("file:/C:/myfile.mpg");
                if (loc == null) {
                    throw new Exception("factory.createLocator() == null");
                }
        
        
            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }

            prt("FYI: toExternalForm = " + loc.toExternalForm());

            try {
                loc = factory.createLocator(null);
                prt("FAILURE: should have raised a NullPointerException");
                new Exception().printStackTrace();
                passed = false;
        
            } catch (NullPointerException npe) {
                prt("PASSED: negative test createLocator(null)");

            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }

            try {
                loc = factory.createLocator("1111");
                prt("FAILURE: should have raised a MalformedLocatorException");
                new Exception().printStackTrace();
                passed = false;
        
            } catch (MalformedLocatorException mle) {
                prt("PASSED: negative test createLocator(1111)");

            } catch (Exception e) {
                prt("FAILURE: " + e);
                e.printStackTrace();
                passed = false;
            }

        } catch (Exception e) {
            prt("FAILURE: " + e);
            e.printStackTrace();
            passed = false;
        }

        if (passed) {
            prt("LocatorTest: PASSED...");

        } else {
            prt("LocatorTest: FAILED...");

        }
        System.exit((passed == true) ? 0 : 1);
    }
}
