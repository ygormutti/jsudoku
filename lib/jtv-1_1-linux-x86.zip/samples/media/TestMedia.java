/*
 * @(#)TestMedia.java	1.9 05/11/23
 * 
 * Copyright � 2005 Sun Microsystems, Inc. All rights reserved. 
 * Use is subject to license terms.
 * 
 */

import javax.tv.locator.Locator;
import javax.tv.locator.LocatorFactory;
import javax.tv.service.Service;
import javax.tv.service.SIManager;
import javax.tv.service.selection.ServiceContext;
import javax.tv.service.selection.ServiceContextFactory;
import java.util.Properties;

public class TestMedia  {

    static { 
        String contentPathProp = "java.content.handler.pkgs";
        Properties props = System.getProperties();
        props.put(contentPathProp, "com.sun.media.content");
        System.setProperties(props);
    }

    public static void main(String args[]) {
        Locator locator = null;
        LocatorFactory factory = null;

        try {
            SIManager manager = SIManager.createInstance();
            if (manager == null) {
                throw new Exception("SIManager.createInstance() == null");
            }

            factory = LocatorFactory.getInstance();
            if (factory == null) {
                throw new Exception("LocatorFactory.getInstance() == null");
            }

            locator = factory.createLocator("service:/SERV1");
            if (locator == null) {
                throw new Exception("factory.createLocator() == null");
            }

            ServiceContextFactory scFactory =
                ServiceContextFactory.getInstance();
            if (scFactory == null) {
                throw new Exception("ServiceContextFactory == null");
            }

            ServiceContext context = scFactory.createServiceContext();
            if (context == null) {
                throw new Exception("createServiceContext == null");
            }

            Service service = manager.getService(locator);
            if (service == null) {
                throw new Exception("getService == null");
            }

            context.select(service);
        
        } catch (Exception e) {
            System.out.println("FAILURE: " + e);
            e.printStackTrace();
        }
    }
}

