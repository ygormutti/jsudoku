/*
 * @(#)SvcDispXlet.java	1.9 05/11/23
 * 
 * Copyright � 2005 Sun Microsystems, Inc. All rights reserved. 
 * Use is subject to license terms.
 * 
 */

import javax.tv.graphics.TVContainer;
import javax.tv.service.SIManager;
import javax.tv.service.navigation.ServiceList;
import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.SystemColor;

import java.util.Vector;

/**
 * A small example xlet which will ask for a list of
 * available services and display their names graphically.
 */

public class SvcDispXlet implements Xlet {

    private Container root_container = null;
    private SIManager si_manager = null;

    // init method
    // Get our container, set size and layout, and create
    // an SIManager instance.
    public void initXlet(XletContext ctx) {
        
        root_container = TVContainer.getRootContainer(ctx);
        root_container.setLayout(new GridLayout(0, 1));
        root_container.setSize(new Dimension(640, 480));
        root_container.setVisible(true);

        si_manager = SIManager.createInstance();
    }

    // start method
    // When we start, find out what services are available
    // and add a label for each to the root container.
    public void startXlet(){
        ServiceList collection = 
            si_manager.filterServices(null);
        LabelComponent sc = null;
        for (int i = 0; i < collection.size(); i++) {
            String name = collection.getService(i).getName();
            if (name != null) {
                sc = new LabelComponent(name);
                root_container.add(sc);
                sc.setVisible(true);
            }
        }
        root_container.validate();
    }

    // pause
    public void pauseXlet() { }

    // destroy
    public void destroyXlet(boolean unconditional) { }

    // Extend Component to create a simple label-like
    // object which we can use to display service names.
    private class LabelComponent extends Component
    {
        String labelStr = null;

        LabelComponent( String serviceName )
        {
            super();
            this.labelStr = serviceName;
        }


        public void paint(Graphics g) {
            FontMetrics fontMetrics = g.getFontMetrics();
            int y = (getSize().height - fontMetrics.getHeight()) / 2;
            g.setColor(SystemColor.white);
            g.fillRect(0, 0, getSize().width, getSize().height);
            g.setColor(SystemColor.black);
            g.drawString(labelStr, 0, fontMetrics.getAscent());
            return;
        }
    }

}
 
