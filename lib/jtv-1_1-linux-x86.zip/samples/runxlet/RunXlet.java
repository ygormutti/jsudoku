/*
 * @(#)RunXlet.java	1.13 05/11/23
 * 
 * Copyright � 2005 Sun Microsystems, Inc. All rights reserved. 
 * Use is subject to license terms.
 * 
 */

import com.sun.tv.receiver.SIEmulator;

/*
 * Run an xlet provided as a command line argument.
 */
public class RunXlet {
    SIEmulator emulator = null;
    public boolean load_si = true;

    // set up everything
    private void setUp() {
        emulator = new SIEmulator();
        
        emulator.isCaughtUp();
    }

    private void startXlet(String xlet_name) {
        emulator.putXlet(0,xlet_name, xlet_name, null);
    }

    public static void main(String args[]) {
        String xlet1 = null;
        boolean load_si = true;

        if (args.length < 1) {
            System.out.println("ERROR: you must specify at least 1 Xlet");
            System.out.println("usage: RunXlet [-n] <classname>");
            System.out.println("  -n     Does not load SI DB");
            System.exit(1);
        }

        if (args[0].equals("-n")) {
            xlet1 = args[1];
            load_si = false;
        } else {
            xlet1 = args[0];
        }

        System.out.println("Running Xlet named: " + xlet1);
        RunXlet rxl = new RunXlet();
        rxl.load_si = load_si;
        rxl.setUp();

        rxl.startXlet(xlet1);
    }
}
