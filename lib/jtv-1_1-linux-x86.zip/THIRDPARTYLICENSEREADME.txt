%% The following software may be included in this product:  
SAX 2.0.  

Use of any of this software is subject to the following:

There is not a license - it is in the public domain

Copyright Disclaimers 
This page includes statements to that effect by David Megginson, who would have
been able to claim copyright for the original work. 

SAX 1.0 
Version 1.0 of the Simple API for XML (SAX), created collectively by the
membership of the XML-DEV mailing list, is hereby released into the public
domain.

No one owns SAX: you may use it freely in both commercial and non-commercial
applications, bundle it with your software distribution, include it on a CD-ROM,
list the source code in a book, mirror the documentation at your own web site,
or use it in any other way you see fit.

SAX 2.0 
I hereby abandon any property rights to SAX 2.0 (the Simple API for XML), and
release all of the SAX 2.0 source code, compiled code, and documentation
contained in this distribution into the Public Domain. SAX comes with NO
WARRANTY or guarantee of fitness for any purpose.

                          David Megginson, david@megginson.com
                          2000-05-05
